<?php
error_reporting(0)
?>
<div id="nav">
				<ul>
						<li><a href="media.php?modul=home">DASHBOARD</a></li>
				</ul>
				<ul>
						<li><a href="media.php?modul=mahasiswa">MASTER MAHASISWA</a></li>
						<li><a href="media.php?modul=dosen">MASTER DOSEN</a></li>
						<li><a href="media.php?modul=kelompok">MASTER KELOMPOK</a></li>
						
				</ul>
				<ul>
					<li><a href="media.php?modul=backup">BACK UP</a></li>
				</ul>

				<ul>
					<li><a href="media.php?modul=user">DAFTAR USER</a></li>
				</ul>
				
				<ul>
					<li><a href="logout.php">LOGOUT</a></li>
				</ul>
				
</div>